# main parameters

debug = 0
logInterval = 15
availableExpCnt = 2

logFile = "test.ini"

class DBInfo(object):
    db_host = "localhost"
    db_name = "bolt"
    db_user = "root"
    db_pwd = "1234567"

unlockPass = 'pass'

priceForHour = 100

contacts_file = 'contacts.txt'
stat_lines = 3

coffe_open_hour = 10
